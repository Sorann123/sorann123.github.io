import { world, system } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { handleDecomposeLogic, getLevel, executeSelectedSkill, SKILL_DATA } from "./main.js";

const EXTRA_SKILLS = {
    meteor: { name: "§6§lMETEOR STRIKE", cost: 25000, lv: 70, info: "遥か上空から爆発する火球を召喚する" },
    glacier: { name: "§b§lGLACIER COFFIN", cost: 6000, lv: 45, info: "周囲の敵を凍結させ動きを完全に封じる" },
    nature_wrath: { name: "§a§lNATURE'S WRATH", cost: 3500, lv: 25, info: "大地の怒りを呼び覚ましトゲで貫く" },
    gravity_well: { name: "§e§lGRAVITY WELL", cost: 10000, lv: 55, info: "超重力で敵を中心へ吸い寄せ圧砕する" }
};

Object.assign(SKILL_DATA, EXTRA_SKILLS);

world.beforeEvents.itemUse.subscribe((ev) => {
    const player = ev.source;
    const item = ev.itemStack;

    if (item.typeId === "alk:alchemy_gauntlet") {
        if (player.isSneaking) {
            system.run(() => {
                const ep = player.getDynamicProperty("ep") ?? 0;
                const lv = getLevel(ep);
                const currentSkill = player.getDynamicProperty("selected_skill") ?? "NONE";

                new ActionFormData()
                    .title("§l§dGENESIS CORE §f- §7v5.5")
                    .body(`§7Status Dashboard\n§8- §fLevel: §b${lv}\n§8- §fEnergy: §d${ep.toLocaleString()} EP\n§8- §fActive: §e${currentSkill.toUpperCase()}`)
                    .button("§l§eDECOMPOSE\n§r§8[ インベントリ抽出 ]", "textures/ui/inventory_icon")
                    .button("§l§bSKILL ARCHIVE\n§r§8[ スキルの選択 ]", "textures/ui/magic_icon")
                    .button("§l§6CORE UPGRADE\n§r§8[ 15,000EP消費 ]", "textures/ui/up_arrow")
                    .show(player).then(res => {
                        if (res.canceled) return;

                        if (res.selection === 0) handleDecomposeLogic(player);

                        if (res.selection === 1) {
                            const sm = new ActionFormData().title("§l§bSKILL ARCHIVE");
                            const available = Object.keys(SKILL_DATA).filter(id => lv >= SKILL_DATA[id].lv);

                            if (available.length === 0) {
                                player.sendMessage("§c§l[!] §7使用可能なスキルがありません。");
                                player.dimension.playSound("note.bass", player.location);
                                return;
                            }

                            for (const id of available) {
                                const s = SKILL_DATA[id];
                                const isSelected = currentSkill === id;
                                sm.button(`${isSelected ? "§6▶ " : ""}${s.name}\n§8Cost: ${s.cost} EP | ${s.info}`);
                            }

                            sm.show(player).then(sr => {
                                if (sr.canceled) return;
                                const skillId = available[sr.selection];
                                player.setDynamicProperty("selected_skill", skillId);
                                player.dimension.playSound("random.orb", player.location, { pitch: 1.5 });
                                player.onScreenDisplay.setActionBar(`§e§lSET: §f${SKILL_DATA[skillId].name}`);
                            });
                        }

                        if (res.selection === 2) {
                            if (ep >= 15000) {
                                player.setDynamicProperty("ep", ep - 15000);
                                const currentUp = player.getDynamicProperty("up_lv") ?? 0;
                                player.setDynamicProperty("up_lv", currentUp + 1);
                                player.dimension.playSound("random.levelup", player.location);
                                player.dimension.spawnParticle("minecraft:totem_particle", player.location);
                                player.sendMessage("§6§l[CORE] §f出力を強化しました。");
                            } else {
                                player.sendMessage("§c§l[!] §7EPが不足しています。");
                                player.dimension.playSound("note.bass", player.location);
                            }
                        }
                    });
            });
        } else {
            system.run(() => {
                executeSelectedSkill(player);
            });
        }
    }

    if (item.typeId === "minecraft:lodestone") {
        system.run(() => {
            const dim = player.dimension;
            const pos = player.location;
            let targetBeacon = null;

            for (let x = -5; x <= 5; x++) {
                for (let y = -5; y <= 5; y++) {
                    for (let z = -5; z <= 5; z++) {
                        const block = dim.getBlock({ x: pos.x + x, y: pos.y + y, z: pos.z + z });
                        if (block?.typeId === "minecraft:beacon") {
                            targetBeacon = block;
                            break;
                        }
                    }
                    if (targetBeacon) break;
                }
                if (targetBeacon) break;
            }

            if (!targetBeacon) {
                player.onScreenDisplay.setActionBar("§c§lBEACON NOT FOUND IN RANGE");
                player.dimension.playSound("note.bass", player.location);
                return;
            }

            let marker = dim.getEntities({ location: targetBeacon.location, maxDistance: 1, families: ["alk:beacon"] })[0];
            if (!marker) {
                marker = dim.spawnEntity("alk:beacon_marker", { x: targetBeacon.location.x + 0.5, y: targetBeacon.location.y, z: targetBeacon.location.z + 0.5 });
                dim.playSound("conduit.activate", marker.location);
                dim.spawnParticle("minecraft:conduit_absorb_particle", marker.location);
            }

            const currentMode = marker.getDynamicProperty("mode") ?? 0;
            const currentRange = marker.getDynamicProperty("range") ?? 32;
            const currentAuto = marker.getDynamicProperty("auto_refuel") ?? true;

            new ModalFormData()
                .title("§l§bTERRITORY CONTROL")
                .dropdown("§7ENGINE MODE\n§8領域内のエンティティへの干渉形式", ["§8STANDBY", "§bANTIGRAVITY", "§dMAGNETIC", "§cANNIHILATION"], currentMode)
                .slider("§7FIELD RANGE\n§8有効稼働半径 (Block)", 8, 128, 8, currentRange)
                .toggle("§7EP AUTO-FEED\n§8プレイヤーからのEP自動供給", currentAuto)
                .show(player).then(res => {
                    if (res.canceled) return;
                    marker.setDynamicProperty("mode", res.formValues[0]);
                    marker.setDynamicProperty("range", res.formValues[1]);
                    marker.setDynamicProperty("auto_refuel", res.formValues[2]);
                    dim.playSound("respawn_anchor.set_spawn", marker.location);
                    dim.spawnParticle("minecraft:eye_of_ender_bubble_particle", marker.location);
                    player.onScreenDisplay.setActionBar("§b§lTERRITORY PARAMETERS SYNCED");
                });
        });
    }
});

system.runInterval(() => {
    for (const player of world.getAllPlayers()) {
        const ep = player.getDynamicProperty("ep") ?? 0;
        const skillId = player.getDynamicProperty("selected_skill") ?? "none";
        const skillName = SKILL_DATA[skillId]?.name ?? "§8NONE";
        
        if (player.getComponent("minecraft:inventory").container.getItem(player.selectedSlotIndex)?.typeId === "alk:alchemy_gauntlet") {
            player.onScreenDisplay.setActionBar(`§7Lv.${getLevel(ep)} §8| §f${ep.toLocaleString()} §bEP §8| §eActive: ${skillName}`);
        }
    }
}, 5);

system.runInterval(() => {
    const dims = [world.getDimension("overworld"), world.getDimension("nether"), world.getDimension("the_end")];
    for (const dim of dims) {
        const beacons = dim.getEntities({ families: ["alk:beacon"] });
        for (const b of beacons) {
            const mode = b.getDynamicProperty("mode") ?? 0;
            if (mode === 0) continue;
            const range = b.getDynamicProperty("range") ?? 32;
            const pos = b.location;

            if (system.currentTick % 20 === 0) {
                dim.spawnParticle("minecraft:basic_portal_particle", pos);
                if (mode === 3) dim.spawnParticle("minecraft:obsidian_tear_particle", { x: pos.x, y: pos.y + 2, z: pos.z });
            }

            const targets = dim.getEntities({ location: pos, maxDistance: range, excludeTypes: ["minecraft:player", "minecraft:item"] });
            for (const t of targets) {
                if (!t.isValid()) continue;
                if (mode === 1) {
                    t.addEffect("levitation", 40, { amplifier: 1, showParticles: false });
                } else if (mode === 2) {
                    const vec = { x: pos.x - t.location.x, y: pos.y - t.location.y, z: pos.z - t.location.z };
                    const dist = Math.sqrt(vec.x ** 2 + vec.y ** 2 + vec.z ** 2);
                    if (dist > 2) t.applyImpulse({ x: (vec.x / dist) * 0.2, y: 0.1, z: (vec.z / dist) * 0.2 });
                } else if (mode === 3) {
                    if (system.currentTick % 10 === 0) {
                        t.applyDamage(4, { cause: "magic" });
                        dim.spawnParticle("minecraft:critical_hit_particle", t.location);
                    }
                }
            }
        }
    }
}, 1);