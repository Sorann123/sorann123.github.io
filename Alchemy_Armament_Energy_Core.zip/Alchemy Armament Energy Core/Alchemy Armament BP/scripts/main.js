import { world, system, EntityDamageCause } from "@minecraft/server";

const ENERGY_DB = {
    "minecraft:copper_ingot": 45, "minecraft:raw_copper": 35, "minecraft:copper_block": 450,
    "minecraft:iron_ingot": 150, "minecraft:raw_iron": 120, "minecraft:iron_block": 1500,
    "minecraft:gold_ingot": 350, "minecraft:raw_gold": 300, "minecraft:gold_block": 3500,
    "minecraft:diamond": 1200, "minecraft:diamond_block": 12000,
    "minecraft:emerald": 500, "minecraft:emerald_block": 5000,
    "minecraft:netherite_ingot": 6000, "minecraft:netherite_block": 60000, "minecraft:ancient_debris": 5000,
    "minecraft:nether_star": 100000, "minecraft:dragon_egg": 250000, "minecraft:dragon_breath": 8000,
    "minecraft:totem_of_undying": 25000, "minecraft:enchanted_golden_apple": 40000,
    "minecraft:elytra": 30000, "minecraft:beacon": 25000, "minecraft:end_crystal": 8000,
    "minecraft:shulker_shell": 1200, "minecraft:shulker_box": 4000, "minecraft:obsidian": 80,
    "minecraft:crying_obsidian": 1200, "minecraft:wither_skeleton_skull": 4000,
    "minecraft:echo_shard": 6000, "minecraft:amethyst_shard": 300,
    "minecraft:heavy_core": 80000, "minecraft:trial_key": 2000, "minecraft:omni_trial_key": 7000
};

const FINAL_BOSS_ID = "myname:solar_emperor";
const BEACON_FAMILY = "alk:beacon";
const OVERLOAD_THRESHOLD = 150000;

export const getLevel = (ep) => Math.floor(Math.sqrt(ep / 100));

export function spawnVisualSpiral(dim, loc, particle, radius, height, points) {
    for (let i = 0; i < points; i++) {
        const angle = (i * Math.PI * 4) / points;
        const h = (i / points) * height;
        dim.spawnParticle(particle, { x: loc.x + Math.cos(angle) * radius, y: loc.y + h, z: loc.z + Math.sin(angle) * radius });
    }
}

export const SKILL_DATA = {
    burst: { name: "§c§lALCHEMY BURST", cost: 0, lv: 5, info: "周囲を吹き飛ばす衝撃波" },
    void_step: { name: "§d§lVOID STEP", cost: 800, lv: 15, info: "視線の先へ空間転移" },
    nature_wrath: { name: "§a§lNATURE'S WRATH", cost: 3500, lv: 25, info: "地面からトゲを連続召喚" },
    overdrive: { name: "§6§lCORE OVERDRIVE", cost: 4000, lv: 35, info: "全能力の一時的な極大強化" },
    glacier: { name: "§b§lGLACIER COFFIN", cost: 6000, lv: 45, info: "周囲の敵を凍結させ拘束する" },
    gravity_well: { name: "§e§lGRAVITY WELL", cost: 10000, lv: 55, info: "超重力で吸い寄せ爆発させる" },
    plasma_rain: { name: "§b§lPLASMA RAIN", cost: 12000, lv: 65, info: "広範囲に雷撃の雨を降らせる" },
    meteor: { name: "§6§lMETEOR STRIKE", cost: 30000, lv: 80, info: "空から巨大な火球を落とす" }
};

export function executeSelectedSkill(player) {
    const skillId = player.getDynamicProperty("selected_skill");
    const ep = player.getDynamicProperty("ep") ?? 0;
    const skill = SKILL_DATA[skillId];

    if (!skill || getLevel(ep) < skill.lv || ep < skill.cost) {
        player.onScreenDisplay.setActionBar("§c§lERROR: INSUFFICIENT ENERGY OR LEVEL");
        player.dimension.playSound("note.bass", player.location);
        return false;
    }

    const dim = player.dimension;
    const loc = player.location;

    switch (skillId) {
        case "burst":
            const bTargets = dim.getEntities({ location: loc, maxDistance: 10, excludeTypes: ["minecraft:player"] });
            for (const e of bTargets) {
                const vec = { x: e.location.x - loc.x, y: 0.8, z: e.location.z - loc.z };
                e.applyImpulse({ x: vec.x * 0.6, y: 0.6, z: vec.z * 0.6 });
                e.applyDamage(35, { cause: EntityDamageCause.entityExplosion, damager: player });
            }
            dim.spawnParticle("minecraft:huge_explosion_emitter", loc);
            dim.playSound("random.explode", loc);
            break;

        case "void_step":
            const ray = player.getBlockFromViewDirection({ maxDistance: 150 });
            if (ray) {
                const targetLoc = { x: ray.block.location.x, y: ray.block.location.y + 1, z: ray.block.location.z };
                spawnVisualSpiral(dim, loc, "minecraft:portal_particle", 1, 2, 20);
                player.teleport(targetLoc, { checkForBlocks: true });
                dim.playSound("mob.endermen.portal", targetLoc);
            }
            break;

        case "nature_wrath":
            for (let i = 1; i <= 10; i++) {
                system.runTimeout(() => {
                    const view = player.getViewDirection();
                    const target = { x: loc.x + view.x * i * 2, y: loc.y, z: loc.z + view.z * i * 2 };
                    dim.spawnEntity("minecraft:evocation_fang", target);
                    dim.spawnParticle("minecraft:crop_growth_emitter", target);
                }, i * 2);
            }
            dim.playSound("dig.grass", loc);
            break;

        case "overdrive":
            player.addEffect("strength", 1200, { amplifier: 6 });
            player.addEffect("speed", 1200, { amplifier: 3 });
            player.addEffect("resistance", 1200, { amplifier: 3 });
            dim.playSound("random.totem", loc);
            spawnVisualSpiral(dim, loc, "minecraft:enchanted_golden_apple_particle", 2, 3, 40);
            break;

        case "glacier":
            const gTargets = dim.getEntities({ location: loc, maxDistance: 12, excludeTypes: ["minecraft:player"] });
            for (const e of gTargets) {
                e.addEffect("slowness", 200, { amplifier: 10 });
                e.addEffect("weakness", 200, { amplifier: 5 });
                dim.spawnParticle("minecraft:snowflake_particle", e.location);
                e.applyDamage(10, { cause: EntityDamageCause.freezing });
            }
            dim.playSound("random.glass", loc);
            break;

        case "gravity_well":
            const gWellPos = player.getBlockFromViewDirection({ maxDistance: 20 })?.block.location ?? loc;
            for (let i = 0; i < 40; i++) {
                system.runTimeout(() => {
                    dim.spawnParticle("minecraft:portal_particle", gWellPos);
                    const ens = dim.getEntities({ location: gWellPos, maxDistance: 10, excludeTypes: ["minecraft:player"] });
                    for (const e of ens) {
                        const v = { x: gWellPos.x - e.location.x, y: gWellPos.y - e.location.y, z: gWellPos.z - e.location.z };
                        e.applyImpulse({ x: v.x * 0.2, y: v.y * 0.2 + 0.1, z: v.z * 0.2 });
                    }
                    if (i === 39) {
                        dim.playSound("random.explode", gWellPos);
                        dim.spawnParticle("minecraft:huge_explosion_emitter", gWellPos);
                        ens.forEach(e => e.applyDamage(50, { cause: EntityDamageCause.magic, damager: player }));
                    }
                }, i);
            }
            dim.playSound("respawn_anchor.charge", gWellPos);
            break;

        case "plasma_rain":
            const pEnemies = dim.getEntities({ location: loc, maxDistance: 25, excludeTypes: ["minecraft:player"] });
            pEnemies.forEach((e, i) => {
                system.runTimeout(() => {
                    if (e.isValid()) {
                        dim.spawnLightningBolt(e.location);
                        e.applyDamage(40, { cause: EntityDamageCause.lightning });
                    }
                }, i * 1);
            });
            dim.playSound("ambient.weather.thunder", loc);
            break;

        case "meteor":
            const mRay = player.getBlockFromViewDirection({ maxDistance: 60 });
            if (mRay) {
                const target = mRay.block.location;
                for (let h = 30; h >= 0; h--) {
                    system.runTimeout(() => {
                        const currentPos = { x: target.x, y: target.y + h, z: target.z };
                        dim.spawnParticle("minecraft:lava_particle", currentPos);
                        dim.spawnParticle("minecraft:huge_explosion_emitter", currentPos);
                        if (h === 0) {
                            dim.createExplosion(target, 8, { breaksBlocks: false, causesFire: true, source: player });
                            dim.playSound("random.explode", target);
                        }
                    }, (30 - h) * 1);
                }
                dim.playSound("mob.ghast.fireball", loc);
            }
            break;
    }

    player.setDynamicProperty("ep", ep - skill.cost);
    return true;
}

export function handleDecomposeLogic(player) {
    const inv = player.getComponent("minecraft:inventory").container;
    const currentEp = player.getDynamicProperty("ep") ?? 0;
    let gain = 0;

    for (let i = 0; i < inv.size; i++) {
        const item = inv.getItem(i);
        if (item && ENERGY_DB[item.typeId]) {
            gain += ENERGY_DB[item.typeId] * item.amount;
            inv.setItem(i, null);
        }
    }

    if (gain > 0) {
        player.setDynamicProperty("ep", currentEp + gain);
        player.dimension.playSound("respawn_anchor.charge", player.location, { pitch: 1.5 });
        spawnVisualSpiral(player.dimension, player.location, "minecraft:blue_flame_particle", 1.5, 2.5, 20);
        player.onScreenDisplay.setActionBar(`§b§l+${gain.toLocaleString()} EP EXTRACTED`);
    }
    return gain;
}

system.runInterval(() => {
    for (const p of world.getAllPlayers()) {
        const ep = p.getDynamicProperty("ep") ?? 0;
        const lv = getLevel(ep);
        const sid = p.getDynamicProperty("selected_skill") ?? "none";

        if (ep > OVERLOAD_THRESHOLD) {
            p.addEffect("resistance", 40, { amplifier: 1, showParticles: false });
            if (system.currentTick % 20 === 0) {
                p.dimension.spawnParticle("minecraft:obsidian_tear_particle", { x: p.location.x, y: p.location.y + 2, z: p.location.z });
                p.dimension.playSound("ambient.weather.lightning.impact", p.location, { volume: 0.3, pitch: 0.5 });
            }
            p.onScreenDisplay.setActionBar(`§c§lCRITICAL: OVERLOAD §7| §fLv.${lv} §8| §e${sid.toUpperCase()}`);
        } else {
            if (p.getComponent("minecraft:inventory").container.getItem(p.selectedSlotIndex)?.typeId === "alk:alchemy_gauntlet") {
                p.onScreenDisplay.setActionBar(`§7Lv.${lv} §b| §f${ep.toLocaleString()} EP §8| §eSkill: ${sid.toUpperCase()}`);
            }
        }
    }
}, 5);

system.runInterval(() => {
    for (const dim of [world.getDimension("overworld"), world.getDimension("nether"), world.getDimension("the_end")]) {
        const beacons = dim.getEntities({ families: [BEACON_FAMILY] });
        for (const b of beacons) {
            const mode = b.getDynamicProperty("mode") ?? 0;
            if (mode === 0) continue;
            const range = b.getDynamicProperty("range") ?? 32;
            const targets = dim.getEntities({ location: b.location, maxDistance: range, excludeTypes: ["minecraft:player", "minecraft:item"] });
            for (const t of targets) {
                if (mode === 1) t.addEffect("levitation", 20, { amplifier: 2 });
                if (mode === 2) {
                    const v = { x: b.location.x - t.location.x, y: 0.1, z: b.location.z - t.location.z };
                    t.applyImpulse({ x: v.x * 0.2, y: 0.1, z: v.z * 0.2 });
                }
                if (mode === 3 && system.currentTick % 10 === 0) t.applyDamage(10, { cause: EntityDamageCause.magic });
            }
        }
    }
}, 1);

world.afterEvents.entityDie.subscribe((ev) => {
    const killer = ev.damageSource.damager;
    if (killer?.typeId === "minecraft:player") {
        const current = killer.getDynamicProperty("ep") ?? 0;
        killer.setDynamicProperty("ep", current + 50);
    }
});